<!DOCTYPE html>
<html>
<head>
<title>SIGN</title>
        <meta http-equiv="X-UA-Compatible" content="IE=EmulateIE7; IE=EmulateIE9">
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1.0, user-scalable=no"/>
    <link rel="stylesheet" type="text/css" href="style.css" media="all" />
    <link rel="stylesheet" type="text/css" href="demo.css" media="all" />
</head>
<body>
<div class="container">
            <div class="idl-top">
                <a href="http://idl.com"><strong>Home</strong></a>
                <!--span class="right">
                    <a href="http://idl.com">
                        <strong>Back to the Login page</strong>
                    </a>
                </span--!>
                <div class="clr"></div>

            </div>
                        <header>
                                <h1> SIGN IN</h1>
                        </header>
		
			<center><img src="images/images.png" alt="Not found"width="100" height="100"></center>
			<br>
			
	   <div class ="form">
			<?php
                        session_start();
                        if(isset($_SESSION['message'])){
                                //echo $_SESSION['message'];
                                echo "<p class='all'>".$_SESSION['message']."<p>";
                                unset ($_SESSION['message']);
                        }
                          if(isset($_SESSION['error'])){
                                //echo $_SESSION['error'];
                                   echo "<p class='all'>".$_SESSION['error']."<p>";
                                unset ($_SESSION['error']);
                        }
                ?>
			<form id="contactform" action="check.php" method="GET">
			<p class="contact"><label for="username">UserName</label></p>
                        <input id="username" name="username" placeholder="username" required="" type="text">
                        <p class="contact"><label for="password">Password</label></p>
                        <input id="password" name="password" placeholder="Enter your password" required="" type="password">

                        <br><br><br>
                        <input class="buttom" name="signin" id="signin" value="Sign in" type="submit">&nbsp;&nbsp;
			<input class="buttom" name="cancel" id="cancel" value="Cancel" type="reset">&nbsp;&nbsp;
			<a href="http://idl.com/reg.php" class="link"><strong>New User?</strong></a>
			</form>
           </div>
</div>
</body>
</html>     

       

