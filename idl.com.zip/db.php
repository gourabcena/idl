<!DOCTYPE html>
<html>
<body>
<?php
	$con = mysqli_connect("idl.com", "root", "johncena","idl");
	if (!$con) {
    			die("Connection failed: " . mysqli_connect_error());
		}
?>
</body>
</html>

